update combustiveis
set nome = "álcool" where nome = "alcool";

