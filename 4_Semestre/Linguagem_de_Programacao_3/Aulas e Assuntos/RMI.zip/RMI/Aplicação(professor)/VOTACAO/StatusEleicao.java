public enum StatusEleicao {
    NAO_INICIADA, EM_ANDAMENTO, ENCERRADA
}
