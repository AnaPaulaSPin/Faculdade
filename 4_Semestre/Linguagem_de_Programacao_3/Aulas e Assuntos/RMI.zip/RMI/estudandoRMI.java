public class estudandoRMI {
    
}
