public class informacoes {
    private int tempo;
    private int entrada;
    private int saida;

    public int getTempo(){
        return this.tempo;
    }
    public void setTempo(int tempo){
        this.tempo = tempo;
    }

    public void setEntrada(int entrada){
        this.entrada = entrada;
    }
    public int getEntrada(){
        return this.entrada;
    }

    public int getSaida(){
        return this.saida;
    }

    public void setSaida(int saida){
         this.saida = saida;
    }
}
